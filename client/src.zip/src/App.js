import React from "react";
import {createRoot} from 'react-dom/client';
import {BrowserRouter as Router} from 'react-router-dom';
import {
  useRoutes
} from 'react-router-dom';
// We use Route in order to define the different routes of our application
import { Route, Routes } from "react-router-dom";
 
 
// We import all the components we need in our app

import IngresarPaciente from "./recursos/IngresarPaciente";
import Navbar from "./recursos/navbar";



const App = () => {
  return (
    <div>
      <Navbar />
      <Routes>


        <Route path="/ingresarPaciente" element={<IngresarPaciente />} />

      </Routes>
    </div>
  );
 };

 export default App;


